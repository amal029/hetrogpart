hetrogpart
==========

Partitoning heuristics for heterogeneous architectures